# Rose Social 🌹

A simple social-media MVP with a responsive website and a mobile app starter.

## Features
- Home feed
- Create posts
- Likes and comments
- User profiles
- Search
- Notifications
- Responsive mobile-first UI

## Website
Open `website/index.html` in a browser.

## Mobile app
The `mobile-app` folder contains an Expo/React Native starter. Install Expo and run it with `npx expo start`.

## GitHub
Create a new GitHub repository and upload this folder, or use:

```bash
git init
git add .
git commit -m "Initial Rose Social app"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

This is a frontend MVP. Authentication, cloud database, image uploads, and real-time messaging can be connected later.
