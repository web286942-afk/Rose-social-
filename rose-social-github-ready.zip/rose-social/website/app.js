const posts=[
 {name:"Maya Chen",handle:"@maya",time:"12m",text:"Sunset walks and good conversations 🌅",likes:128,comments:14},
 {name:"Alex Rai",handle:"@alexrai",time:"1h",text:"Building something new today. Small steps, big dreams. 🚀",likes:74,comments:9},
 {name:"Nina Park",handle:"@ninapark",time:"3h",text:"Photography tip: look for the light before you look for the subject. 📷",likes:213,comments:27}
];

function render(){
 const q=(document.getElementById("search").value||"").toLowerCase();
 document.getElementById("feed").innerHTML=posts.filter(p=>p.text.toLowerCase().includes(q)||p.name.toLowerCase().includes(q)).map((p,i)=>`
 <article class="post">
  <div class="post-head"><div class="avatar">${p.name[0]}</div><div><div class="post-user">${p.name}</div><div class="muted">${p.handle} · ${p.time}</div></div></div>
  <div class="post-body">${escapeHtml(p.text)}</div>
  <div class="actions">
   <button onclick="like(${i})">❤️ ${p.likes}</button>
   <button onclick="showToast('Comments coming next')">💬 ${p.comments}</button>
   <button onclick="showToast('Post shared')">↗ Share</button>
  </div>
 </article>`).join("");
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function like(i){posts[i].likes++;render()}
function createPost(){
 const el=document.getElementById("postText"), text=el.value.trim();
 if(!text)return showToast("Write something first");
 posts.unshift({name:"Meigui Rose",handle:"@meigui",time:"now",text,likes:0,comments:0});
 el.value="";render();showToast("Posted 🌹");
}
function showToast(msg){const t=document.getElementById("toast");t.textContent=msg;t.style.display="block";setTimeout(()=>t.style.display="none",1800)}
document.getElementById("search").addEventListener("input",render);render();
