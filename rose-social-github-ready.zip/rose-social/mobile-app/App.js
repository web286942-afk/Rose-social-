import React,{useState} from 'react';
import {SafeAreaView,View,Text,TextInput,TouchableOpacity,FlatList,StyleSheet} from 'react-native';

const initial=[
 {id:'1',name:'Maya Chen',text:'Sunset walks and good conversations 🌅',likes:128},
 {id:'2',name:'Alex Rai',text:'Building something new today. Small steps, big dreams. 🚀',likes:74},
 {id:'3',name:'Nina Park',text:'Photography tip: look for the light before you look for the subject. 📷',likes:213}
];

export default function App(){
 const [posts,setPosts]=useState(initial);
 const [text,setText]=useState('');
 const add=()=>{if(!text.trim())return;setPosts([{id:Date.now().toString(),name:'Meigui Rose',text,likes:0},...posts]);setText('')};
 const like=id=>setPosts(posts.map(p=>p.id===id?{...p,likes:p.likes+1}:p));
 return <SafeAreaView style={s.safe}>
  <Text style={s.logo}>🌹 Rose</Text>
  <TextInput style={s.search} placeholder="Search Rose Social..." />
  <View style={s.compose}><TextInput value={text} onChangeText={setText} placeholder="What's happening?" style={s.input}/><TouchableOpacity style={s.btn} onPress={add}><Text style={s.btnText}>Post</Text></TouchableOpacity></View>
  <FlatList data={posts} keyExtractor={p=>p.id} renderItem={({item})=><View style={s.card}>
   <Text style={s.name}>● {item.name}</Text><Text style={s.body}>{item.text}</Text>
   <TouchableOpacity onPress={()=>like(item.id)}><Text style={s.action}>❤️ {item.likes}    💬 Comment    ↗ Share</Text></TouchableOpacity>
  </View>}/>
  <View style={s.nav}><Text>🏠</Text><Text>🔎</Text><Text>➕</Text><Text>❤️</Text><Text>👤</Text></View>
 </SafeAreaView>
}
const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:'#f7f5f8',padding:16},logo:{fontSize:26,fontWeight:'800',color:'#d43d70',marginBottom:12},
 search:{backgroundColor:'#eee9ee',borderRadius:24,padding:12,marginBottom:12},compose:{backgroundColor:'#fff',borderRadius:16,padding:12,marginBottom:12},
 input:{minHeight:45},btn:{backgroundColor:'#d43d70',alignSelf:'flex-end',paddingHorizontal:18,paddingVertical:9,borderRadius:20},btnText:{color:'#fff',fontWeight:'700'},
 card:{backgroundColor:'#fff',borderRadius:16,padding:16,marginBottom:12},name:{fontWeight:'700',marginBottom:10},body:{fontSize:16,lineHeight:24,marginBottom:15},action:{color:'#6d626d'},
 nav:{height:58,backgroundColor:'#fff',borderRadius:20,flexDirection:'row',justifyContent:'space-around',alignItems:'center',marginTop:6}
});
